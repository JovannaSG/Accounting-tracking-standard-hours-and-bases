# core/audit.py
"""Глубокий аудит данных 1С:Фреш (Phase 2-3).

Checkpoint-состояние живёт в отдельной БД ``audit_history.db``
(``core.db.init_audit_db``), движок строго последователен по базе и
покрыт ``tests/test_audit.py``.

Запуск из CLI::

    python -m core.audit --base <имя> --start 2026-01-01 --end 2026-01-31 \\
        [--include-unmapped] [--pause 0.2] [--restart]

Отчёт пишется в ``exports/audit_*.xlsx`` (листы «Сводка», «Проблемы»,
«Gaps»).
"""
from __future__ import annotations

import argparse
import fcntl
import os
import signal
import sys
import time
from contextlib import contextmanager
from datetime import datetime
from datetime import date
from pathlib import Path
from typing import Any
from urllib.parse import quote

import openpyxl

from core import config, db
from core.api_client import EntityNotFoundError, OneCClient
from core.norms import load_doc_types
from core.reporters import BORDER, CENTER, HEADER_FILL, HEADER_FONT


class AuditBusyError(RuntimeError):
    """Аудит уже выполняется: блокировка удерживается другим процессом."""

_TIME = time  # патчится в тестах (паузы между запросами)

# Возврат _run_chunk для сущности, отсутствующей в базе (404, не применимо).
_CHUNK_NOT_APPLICABLE = "NOT_APPLICABLE"

# ====================== ЧАНКИНГ ПО КАЛЕНДАРНЫМ МЕСЯЦАМ ======================


def _month_chunks(period_start: str, period_end: str) -> list[tuple[str, str]]:
    """Дробит период на календарные месяцы (включительно).

    ``("2026-01-15", "2026-03-10")`` ->
    ``[("2026-01-15","2026-01-31"), ("2026-02-01","2026-02-28"),
    ("2026-03-01","2026-03-10")]``. Точные границы reduce запросов
    1С:Фреш и дают естественные «фрагменты» для checkpoint'ов.
    """
    from calendar import monthrange

    s = date.fromisoformat(period_start)
    e = date.fromisoformat(period_end)
    if e < s:
        raise ValueError(
            f"Период некорректен: {period_start} позже {period_end}"
        )

    chunks: list[tuple[str, str]] = []
    cur = s
    while cur <= e:
        month_last = cur.replace(day=monthrange(cur.year, cur.month)[1])
        end = month_last if month_last < e else e
        chunks.append((cur.isoformat(), end.isoformat()))
        cur = date(cur.year + 1, 1, 1) if cur.month == 12 else date(
            cur.year, cur.month + 1, 1
        )
    return chunks


# =========================== УТИЛИТЫ ТРАНСПОРТА ==============================


def _amount(rec: dict) -> float:
    """Числовой итог документа; мусор/None → 0.0 (не роняем чанк)."""

    raw = rec.get("СуммаДокумента")
    try:
        return float(raw or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _count_records(
    client: OneCClient,
    entity: str,
    chunk_start: str,
    chunk_end: str,
) -> tuple[int | None, bool]:
    """Лёгкий ``$top=1&$count=true`` с тем же фильтром по Date.

    Возвращает ``(total, available)``. Если 1С отвергла ``$count``
    (донор не публикует регистры/не знает оператора) — ``(None, False)``:
    аудит деградирует в export-only, без hard-fail.
    """
    start_safe = client._start_of_day(chunk_start)
    end_safe = client._end_of_day(chunk_end)
    ffilter = (
        f"Date ge datetime'{start_safe}' "
        f"and Date le datetime'{end_safe}'"
    )
    endpoint = (
        f"{client.base_url}/odata/standard.odata/{entity}"
        f"?{r'$format'}=json&{r'$filter'}={quote(ffilter, safe='')}"
        f"&{r'$top'}=1&{r'$count'}=true"
    )
    try:
        data = client._request_page(endpoint, {})
    except ValueError:
        return None, False
    count = data.get("@odata.count", data.get("odata.count"))
    if count is None:
        return None, False
    try:
        return int(count), True
    except (TypeError, ValueError):
        return None, False


# ====================== БЛОКИРОВКА И СИГНАЛЫ ================================


@contextmanager
def _audit_lock(path: str):
    """Эксклюзивная блокировка аудита (flock, неблокирующая).

    Держится процессом на всё время прогона; автоматически снимается ОС при
    завершении (в т.ч. по SIGTERM/Ctrl+C), поэтому устаревший файл не мешает.
    Если блокировка занята другим процессом (UI или cron) — ``AuditBusyError``.
    """

    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as e:
        os.close(fd)
        raise AuditBusyError(
            f"Аудит уже выполняется (блокировка {path})"
        ) from e
    try:
        yield fd
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _install_sigterm_handler() -> None:
    """SIGTERM (кнопка «Остановить» в UI) → KeyboardInterrupt.

    Так остановка из UI использует тот же бережный путь, что и Ctrl+C:
    сообщение «состояние сохранено», код 130, незавершённый чанк остаётся
    RUNNING и продолжается при следующем запуске.
    """

    def _raise(signum, frame):
        raise KeyboardInterrupt

    try:
        signal.signal(signal.SIGTERM, _raise)
    except (ValueError, AttributeError, OSError):
        # Не главный поток или платформа без SIGTERM — не критично.
        pass


# ============================= ДВИЖОК АУДИТА =================================


def _audit_entities(base: dict) -> list[str]:
    """Уникальные OData-сущности реестра в порядке doc_types.json.

    Учитывает ``bases.active_doc_types``: пустой список = все виды реестра
    (прецедент — core.fetch.fetch_documents).
    """
    registry = load_doc_types()
    keys = base.get("active_doc_types") or list(registry.keys())
    entities: list[str] = []
    for key in keys:
        spec = registry.get(key)
        if spec and spec.get("entity") and spec["entity"] not in entities:
            entities.append(spec["entity"])
    return entities


def run_audit(
    base: dict,
    period_start: str,
    period_end: str,
    pause: float = 0.2,
    include_unmapped: bool = False,
    client: OneCClient | None = None,
    restart: bool = False,
    entities: list[str] | None = None,
) -> dict:
    """Прогоняет аудит базы за период; резюмирует через checkpoint'ы.

    - (entity × месяц) как чанк: COMPLETED пропускаются, RUNNING/FAILED
      перезапускаются ровно с этой точки (без дублей сети);
    - каждый чанк: стрим ``fetch_documents_iter`` (память O(1)),
      агрегаты rows/сумма/страницы, затем ``$count``-gate;
    - деградация на минимальный ``$select`` (``client._degraded_entities``)
      фиксируется как data-poor;
    - ``include_unmapped`` — подсчёт нереестровых ``Document_*`` из
      ``$metadata`` (``$count``-only, с паузами).

    ``client``/``entities`` — тестовые интерфейсы: движок не строит сетевого
    клиента, если клиент уже передан; сущности — из реестра, а не сети.
    """
    base_url = str(base["url"]).rstrip("/")
    client = client or OneCClient(
        base_url, base.get("login") or "", base.get("password") or ""
    )

    init_audit_db = db.init_audit_db
    init_audit_db()
    conn = db._audit_conn()
    try:
        now = datetime.now().isoformat(timespec="seconds")
        conn.execute(
            "INSERT INTO audit_runs (base_url, period_start, period_end, "
            "include_unmapped, status, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (base_url, period_start, period_end, int(bool(include_unmapped)),
             db.AUDIT_RUN_PENDING, now),
        )
        run_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.commit()
    finally:
        conn.close()

    summary: dict[str, Any] = {
        "run_id": run_id,
        "base_url": base_url,
        "base_name": base.get("name", ""),
        "period_start": period_start,
        "period_end": period_end,
        "chunks_total": 0,
        "chunks_completed": 0,
        "chunks_skipped": 0,
        "chunks_failed": 0,
        "count_mismatches": 0,
        "degraded_entities": [],
    }

    chunk_items = [
        (entity, chunk)
        for entity in (entities or _audit_entities(base))
        for chunk in _month_chunks(period_start, period_end)
    ]
    summary["chunks_total"] = len(chunk_items)

    try:
        for entity, (chunk_start, chunk_end) in chunk_items:
            status = _run_chunk(
                client, run_id, base_url, entity,
                chunk_start, chunk_end, pause, restart,
            )
            if status in ("SKIPPED", _CHUNK_NOT_APPLICABLE):
                summary["chunks_skipped"] += 1
            elif status == db.AUDIT_CP_COMPLETED:
                summary["chunks_completed"] += 1
            elif status == db.AUDIT_CP_FAILED:
                summary["chunks_failed"] += 1

        summary["degraded_entities"] = sorted(client._degraded_entities)

        if include_unmapped:
            gaps = _run_gap_counts(
                client, base_url, run_id,
                entities or _audit_entities(base), pause,
                period_start, period_end,
            )
            summary["gaps_count"] = len(gaps)

        summary["count_mismatches"] = _count_mismatches(run_id)

        run_status = (
            db.AUDIT_RUN_COMPLETED
            if summary["chunks_failed"] == 0
            else db.AUDIT_RUN_FAILED
        )
        _finalize_run(run_id, run_status)
    except Exception as e:
        _finalize_run(run_id, db.AUDIT_RUN_FAILED, error=str(e))
        raise

    summary["run_status"] = run_status
    return summary


def _run_chunk(
    client: OneCClient,
    run_id: int,
    base_url: str,
    entity: str,
    chunk_start: str,
    chunk_end: str,
    pause: float,
    restart: bool,
) -> str:
    """Аудит одного (entity × месяц); возвращает итоговый статус чанка."""

    conn = db._audit_conn()
    try:
        row = conn.execute(
            "SELECT " + ", ".join(db._AUDIT_CHECKPOINTS_COLUMNS)
            + " FROM audit_checkpoints WHERE base_url=? AND entity_name=?"
            + " AND chunk_start=? AND chunk_end=?",
            (base_url, entity, chunk_start, chunk_end),
        ).fetchone()
    finally:
        conn.close()

    if (row is not None and not restart
            and db._audit_row(row, db._AUDIT_CHECKPOINTS_COLUMNS)["status"]
            == db.AUDIT_CP_COMPLETED):
        # Чанк уже выполнен в прошлом прогоне. Перечитывать его не нужно, но
        # его checkpoint должен «принадлежать» текущему run'у: иначе отчёт
        # (list_audit_checkpoints по run_id) после резюма потерял бы все
        # ранее завершённые чанки — вместе с их $count-расхождениями и
        # деградацией. Это тот же приём, что и у audit_gap_counts.
        conn = db._audit_conn()
        try:
            conn.execute(
                "UPDATE audit_checkpoints SET run_id=? "
                "WHERE base_url=? AND entity_name=? AND chunk_start=? "
                "AND chunk_end=?",
                (run_id, base_url, entity, chunk_start, chunk_end),
            )
            conn.commit()
        finally:
            conn.close()
        return "SKIPPED"

    now = datetime.now().isoformat(timespec="seconds")
    conn = db._audit_conn()
    try:
        conn.execute(
            "INSERT INTO audit_checkpoints (run_id, base_url, entity_name, "
            "chunk_start, chunk_end, status, started_at, rows_processed) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, 0) "
            "ON CONFLICT(base_url, entity_name, chunk_start, chunk_end) "
            "DO UPDATE SET run_id=excluded.run_id, status='RUNNING', "
            "started_at=excluded.started_at, rows_processed=0, sum_amount=NULL, "
            "page_count=0, degraded=0, expected_count=NULL, "
            "count_available=0, count_mismatch=0, error=NULL, finished_at=NULL",
            (run_id, base_url, entity, chunk_start, chunk_end,
             db.AUDIT_CP_RUNNING, now),
        )
        conn.commit()
    finally:
        conn.close()

    rows = 0
    total = 0.0
    pages = 0

    def _on_page() -> None:
        nonlocal pages
        pages += 1

    try:
        for rec in client.fetch_documents_iter(
            entity, chunk_start, chunk_end, pause=pause, on_page=_on_page
        ):
            rows += 1
            total += _amount(rec)

        count, count_available = _count_records(
            client, entity, chunk_start, chunk_end
        )
        mismatch = (abs(count - rows) if count_available and count is not None
                    else 0)
        degraded = 1 if entity in client._degraded_entities else 0
        finished = datetime.now().isoformat(timespec="seconds")

        conn = db._audit_conn()
        try:
            conn.execute(
                "UPDATE audit_checkpoints SET status=?, rows_processed=?, "
                "sum_amount=?, page_count=?, degraded=?, expected_count=?, "
                "count_available=?, count_mismatch=?, finished_at=? "
                "WHERE base_url=? AND entity_name=? AND chunk_start=? "
                "AND chunk_end=?",
                (db.AUDIT_CP_COMPLETED, rows, round(total, 2), pages,
                 degraded, count, int(count_available), mismatch, finished,
                 base_url, entity, chunk_start, chunk_end),
            )
            conn.commit()
        finally:
            conn.close()
        return db.AUDIT_CP_COMPLETED
    except EntityNotFoundError:
        # 404: сущности нет в этой базе (не активирован контур — ГТД, зарплата
        # и т.п.). Это не сбой: помечаем COMPLETED с 0 строк, чтобы (а) резюм
        # не дёргал её снова и (б) она не попала в «Проблемы». Пометка в
        # error видна в «Сводке», но «Проблемы» фильтруют по COMPLETED.
        finished = datetime.now().isoformat(timespec="seconds")
        conn = db._audit_conn()
        try:
            conn.execute(
                "UPDATE audit_checkpoints SET status=?, rows_processed=0, "
                "sum_amount=0, page_count=0, degraded=0, expected_count=NULL, "
                "count_available=0, count_mismatch=0, error=?, finished_at=? "
                "WHERE base_url=? AND entity_name=? AND chunk_start=? "
                "AND chunk_end=?",
                (db.AUDIT_CP_COMPLETED, "сущность отсутствует в базе (404)",
                 finished, base_url, entity, chunk_start, chunk_end),
            )
            conn.commit()
        finally:
            conn.close()
        return _CHUNK_NOT_APPLICABLE
    except Exception as e:
        failed = datetime.now().isoformat(timespec="seconds")
        conn = db._audit_conn()
        try:
            conn.execute(
                "UPDATE audit_checkpoints SET status=?, error=?, finished_at=? "
                "WHERE base_url=? AND entity_name=? AND chunk_start=? "
                "AND chunk_end=?",
                (db.AUDIT_CP_FAILED, str(e)[:500], failed,
                 base_url, entity, chunk_start, chunk_end),
            )
            conn.commit()
        finally:
            conn.close()
        return db.AUDIT_CP_FAILED


def _run_gap_counts(
    client: OneCClient,
    base_url: str,
    run_id: int,
    registry_entities: list[str],
    pause: float,
    period_start: str,
    period_end: str,
) -> list[dict]:
    """Счётчики нереестровых ``Document_*`` (только --include-unmapped).

    Список сущностей берётся из ``$metadata``, нереестровые обходятся
    ``$count``-only с паузами; результат складывается в ``audit_gap_counts``
    и возвращается для отчёта.
    """
    registry_set = set(registry_entities)
    try:
        sets = client.fetch_metadata_entity_sets()
    except ValueError as e:
        raise ValueError(f"Не удалось получить $metadata для gaps: {e}") from e

    gaps: list[dict] = []
    now = datetime.now().isoformat(timespec="seconds")
    conn = db._audit_conn()
    try:
        for name in sorted(sets):
            if not name.startswith("Document_") or name in registry_set:
                continue
            if pause > 0:
                _TIME.sleep(pause)
            count, available = _count_records(
                client, name, period_start, period_end
            )
            conn.execute(
                "INSERT INTO audit_gap_counts (base_url, entity_name, run_id, "
                "doc_count, count_available, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(base_url, entity_name) DO UPDATE SET "
                "run_id=excluded.run_id, doc_count=excluded.doc_count, "
                "count_available=excluded.count_available, "
                "updated_at=excluded.updated_at",
                (base_url, name, run_id, count if count is not None else 0,
                 int(available), now),
            )
            gaps.append({
                "base_url": base_url,
                "entity_name": name,
                "run_id": run_id,
                "doc_count": count if count is not None else 0,
                "count_available": int(available),
                "updated_at": now,
            })
        conn.commit()
    finally:
        conn.close()
    return gaps


def _count_mismatches(run_id: int) -> int:
    conn = db._audit_conn()
    try:
        row = conn.execute(
            "SELECT COUNT(*) FROM audit_checkpoints WHERE run_id=? "
            "AND count_mismatch != 0",
            (run_id,),
        ).fetchone()
        return int(row[0])
    finally:
        conn.close()


def _finalize_run(run_id: int, status: str, error: str | None = None) -> None:
    now = datetime.now().isoformat(timespec="seconds")
    conn = db._audit_conn()
    try:
        if error is None:
            conn.execute(
                "UPDATE audit_runs SET status=?, finished_at=? WHERE id=?",
                (status, now, run_id),
            )
        else:
            conn.execute(
                "UPDATE audit_runs SET status=?, finished_at=? WHERE id=?",
                (db.AUDIT_RUN_FAILED, now, run_id),
            )
            conn.execute(
                "UPDATE audit_checkpoints SET status=?, error=? "
                "WHERE run_id=? AND status IN ('RUNNING','PENDING')",
                (db.AUDIT_CP_FAILED, error[:500], run_id),
            )
        conn.commit()
    finally:
        conn.close()


def _resolve_base(name_or_url: str) -> dict | None:
    """База из таблицы bases по имени (без учёта регистра), URL или id."""

    needle = str(name_or_url or "").strip()
    if not needle:
        return None
    for b in db.list_bases():
        if b["name"].strip().lower() == needle.lower():
            return b
    if needle.lower().startswith(("http://", "https://")):
        return db.get_base(needle)
    for b in db.list_bases():
        if str(b["id"]) == needle:
            return b
    return None


# ================================ ОТЧЁТ ======================================


def write_audit_report(
    summary: dict,
    out_dir: str = "exports",
) -> str:
    """Формирует ``exports/audit_*.xlsx``: «Сводка», «Проблемы», «Gaps».

    Каждая строка Сводки — checkpoint (entity × месяц). «Проблемы» — вход
    для ручной сверки: расхождения с ``$count`` (миграция данных), деградация
    (data-poor), ошибки выгрузки. Возвращает путь к файлу.
    """
    import os

    os.makedirs(out_dir, exist_ok=True)
    safe_name = "".join(
        c if (c.isalnum() or c in "-_.") else "_" for c in summary["base_name"]
    ).strip("_")
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    path = os.path.join(
        out_dir,
        f"audit_{safe_name or 'base'}_{summary['period_start']}_"
        f"{summary['period_end']}_{ts}.xlsx",
    )
    checkpoints = db.list_audit_checkpoints(summary["run_id"])
    gaps = db.list_audit_gap_counts(summary["base_url"])

    workbook = openpyxl.Workbook()

    _write_summary_sheet(workbook, checkpoints, summary)
    _write_problems_sheet(workbook, checkpoints)
    _write_gaps_sheet(workbook, gaps)

    workbook.save(path)
    return path


def _style_headers(ws, headers: list[str]) -> None:
    for col, title in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=title)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    ws.freeze_panes = "A2"


def _cell(ws, row: int, col: int, value) -> None:
    cell = ws.cell(row=row, column=col, value=value)
    cell.border = BORDER
    return cell


def _write_summary_sheet(
    workbook: openpyxl.Workbook,
    checkpoints: list[dict],
    summary: dict,
) -> None:
    ws = workbook.active
    ws.title = "Сводка"
    headers = [
        "Сущность", "Чанк с", "Чанк по", "Строк", "Сумма документов",
        "Страниц", "Данных-бедно", "$count", "Ожидалось", "Расхождение",
        "Статус", "Ошибка",
    ]
    _style_headers(ws, headers)
    for row_i, cp in enumerate(checkpoints, start=2):
        values = [
            cp["entity_name"], cp["chunk_start"], cp["chunk_end"],
            cp["rows_processed"], cp["sum_amount"], cp["page_count"],
            "да" if cp["degraded"] else "",
            "да" if cp["count_available"] else "нет",
            cp["expected_count"], cp["count_mismatch"],
            cp["status"], cp["error"],
        ]
        for col_i, value in enumerate(values, start=1):
            _cell(ws, row_i, col_i, value)
    for col in (4, 5, 6, 9, 10):
        _fmt_column(ws, col, "0" if col in (4, 6, 9, 10) else "0.00")
    ws.column_dimensions["A"].width = 46
    ws.column_dimensions["L"].width = 60


def _fmt_column(ws, col: int, fmt: str) -> None:
    for row in range(2, ws.max_row + 1):
        ws.cell(row=row, column=col).number_format = fmt


def _write_problems_sheet(
    workbook: openpyxl.Workbook,
    checkpoints: list[dict],
) -> None:
    ws = workbook.create_sheet("Проблемы")
    headers = ["Сущность", "Чанк с", "Чанк по", "Проблема", "Детали"]
    _style_headers(ws, headers)
    row_i = 2
    for cp in checkpoints:
        if cp["status"] == db.AUDIT_CP_FAILED:
            problem, detail = ("Ошибка выгрузки", cp["error"] or "")
        elif cp["count_mismatch"]:
            problem = "Расхождение с $count"
            detail = (
                f"ожидалось {cp['expected_count']}, загружено "
                f"{cp['rows_processed']}"
            )
        elif cp["degraded"]:
            problem = "Минимальный набор полей (data-poor)"
            detail = "400/500 на полном $select — деградация на 3 поля"
        else:
            continue
        for col_i, value in enumerate(
            [cp["entity_name"], cp["chunk_start"], cp["chunk_end"],
             problem, detail],
            start=1,
        ):
            _cell(ws, row_i, col_i, value)
        row_i += 1
    ws.column_dimensions["A"].width = 46
    ws.column_dimensions["E"].width = 70


def _write_gaps_sheet(
    workbook: openpyxl.Workbook,
    gaps: list[dict],
) -> None:
    ws = workbook.create_sheet("Gaps")
    headers = ["Сущность", "Количество документов", "$count доступен"]
    _style_headers(ws, headers)
    for row_i, gap in enumerate(gaps, start=2):
        for col_i, value in enumerate(
            [gap["entity_name"], gap["doc_count"],
             "да" if gap["count_available"] else "нет"],
            start=1,
        ):
            _cell(ws, row_i, col_i, value)
    _fmt_column(ws, 2, "0")
    ws.column_dimensions["A"].width = 46


# ================================== CLI ======================================


def _problems_in_checkpoints(checkpoints: list[dict]) -> list[dict]:
    """Проблемные чанки по тем же правилам, что лист «Проблемы» отчёта."""

    return [
        cp for cp in checkpoints
        if cp["status"] == db.AUDIT_CP_FAILED
        or cp["count_mismatch"]
        or cp["degraded"]
    ]


def _summarize_base(base: dict | None, base_url: str) -> dict:
    """Сводка текущего состояния аудита одной базы (из БД, без сети).

    Агрегирует checkpoint'ы по ``base_url`` (см.
    ``db.list_audit_checkpoints_by_base``); статусы чанков: ``done`` —
    завершён со строками, ``empty`` — завершён с 0 строк (отсутствующая
    сущность 404 или пропуск при резюме), ``failed`` — ошибка. Явный
    «пропущено» в БД не хранится, поэтому не подделывается.
    """

    checkpoints = db.list_audit_checkpoints_by_base(base_url)
    done = empty = failed = 0
    rows_total = 0
    sum_total = 0.0
    for cp in checkpoints:
        if cp["status"] == db.AUDIT_CP_FAILED:
            failed += 1
            continue
        if cp["status"] == db.AUDIT_CP_COMPLETED:
            rows_total += cp["rows_processed"] or 0
            sum_total += cp["sum_amount"] or 0.0
            if cp["rows_processed"]:
                done += 1
            else:
                empty += 1

    runs = db.list_audit_runs(base_url=base_url)
    latest = runs[0] if runs else {}
    gaps = db.list_audit_gap_counts(base_url)
    problems = _problems_in_checkpoints(checkpoints)

    return {
        "base_name": (base or {}).get("name") or base_url,
        "base_url": base_url,
        "base_id": (base or {}).get("id"),
        "run_id": latest.get("id"),
        "run_status": latest.get("status"),
        "period_start": latest.get("period_start"),
        "period_end": latest.get("period_end"),
        "include_unmapped": bool(latest.get("include_unmapped")),
        "created_at": latest.get("created_at"),
        "finished_at": latest.get("finished_at"),
        "chunks_total": len(checkpoints),
        "chunks_done": done,
        "chunks_empty": empty,
        "chunks_failed": failed,
        "rows_total": rows_total,
        "sum_total": round(sum_total, 2),
        "mismatches": sum(1 for cp in checkpoints if cp["count_mismatch"]),
        "degraded": sum(1 for cp in checkpoints if cp["degraded"]),
        "gaps_count": len(gaps),
        "problems": len(problems),
        "has_problems": bool(problems),
    }


def audit_summary(base_filter: str | None = None) -> list[dict]:
    """Сводка по базам с историей аудита (свежие базы — по имени).

    ``base_filter`` (имя/URL/id) сужает до одной базы; неизвестная — ValueError.
    """

    names = {b["url"].rstrip("/"): b for b in db.list_bases()}

    if base_filter:
        base = _resolve_base(base_filter)
        if base is None:
            raise ValueError(f"База '{base_filter}' не найдена")
        return [_summarize_base(base, str(base["url"]).rstrip("/"))]

    urls: list[str] = []
    for run in db.list_audit_runs():
        url = str(run["base_url"]).rstrip("/")
        if url not in urls:
            urls.append(url)

    rows = [_summarize_base(names.get(url), url) for url in urls]
    rows.sort(key=lambda r: (not r["has_problems"], str(r["base_name"]).lower()))
    return rows


def audit_base_detail(base_url: str) -> list[dict]:
    """Разбивка чанков базы по сущностям (для ``--summary --base``)."""

    by_entity: dict[str, dict] = {}
    for cp in db.list_audit_checkpoints_by_base(base_url):
        row = by_entity.setdefault(cp["entity_name"], {
            "entity_name": cp["entity_name"], "chunks": 0, "rows": 0,
            "sum": 0.0, "mismatches": 0, "degraded": 0, "failed": 0,
        })
        row["chunks"] += 1
        row["rows"] += cp["rows_processed"] or 0
        row["sum"] += cp["sum_amount"] or 0.0
        if cp["status"] == db.AUDIT_CP_FAILED:
            row["failed"] += 1
        if cp["count_mismatch"]:
            row["mismatches"] += 1
        if cp["degraded"]:
            row["degraded"] += 1
    detail = list(by_entity.values())
    for row in detail:
        row["sum"] = round(row["sum"], 2)
    return detail


def _render_table(headers: list[str], rows: list[list]) -> str:
    """Простая выровненная таблица (ширины по содержимому)."""

    widths = [len(h) for h in headers]
    for row in rows:
        for i, value in enumerate(row):
            widths[i] = max(widths[i], len(str(value)))
    lines = ["  ".join(h.ljust(widths[i]) for i, h in enumerate(headers))]
    lines.append("  ".join("-" * w for w in widths))
    for row in rows:
        lines.append("  ".join(str(v).ljust(widths[i])
                               for i, v in enumerate(row)))
    return "\n".join(lines)


_SUMMARY_HEADERS = [
    "База", "id", "Прогон", "Статус", "Период", "Чанков",
    "Готово", "Пусто", "Ошибок", "Расхожд.", "Данных-бедно", "Gaps", "Проблемы",
]


def _summary_row_values(row: dict) -> list:
    period = (
        f"{row['period_start']}..{row['period_end']}"
        if row["period_start"] else "-"
    )
    return [
        row["base_name"], row["base_id"] if row["base_id"] is not None else "-",
        row["run_id"] if row["run_id"] is not None else "-",
        row["run_status"] or "-", period, row["chunks_total"],
        row["chunks_done"], row["chunks_empty"], row["chunks_failed"],
        row["mismatches"], row["degraded"], row["gaps_count"],
        row["problems"] if row["problems"] else "",
    ]


def _format_summary_table(rows: list[dict]) -> str:
    return _render_table(_SUMMARY_HEADERS, [_summary_row_values(r) for r in rows])


def _format_base_detail(row: dict) -> str:
    """Сводка одной базы + таблица по сущностям."""

    block = [_render_table(_SUMMARY_HEADERS, [_summary_row_values(row)]), ""]
    detail = audit_base_detail(row["base_url"])
    headers = ["Сущность", "Чанков", "Строк", "Сумма документов",
               "Расхожд.", "Данных-бедно", "Ошибок"]
    values = [
        [d["entity_name"], d["chunks"], d["rows"], d["sum"],
         d["mismatches"], d["degraded"], d["failed"]]
        for d in detail
    ]
    block.append(f"Детализация по сущностям ({len(detail)}):")
    block.append(_render_table(headers, values) if values
                 else "(нет данных)")
    return "\n".join(block)


def _summary_json(rows: list[dict]) -> str:
    import json

    return json.dumps(rows, ensure_ascii=False, indent=2)


def _write_summary_file(path: str, rows: list[dict], as_json: bool) -> None:
    """Сохраняет плоскую сводку в файл: JSON либо CSV (разделитель «;»)."""

    if as_json:
        with open(path, "w", encoding="utf-8") as f:
            f.write(_summary_json(rows))
        return

    import csv

    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(_SUMMARY_HEADERS)
        for row in rows:
            writer.writerow(_summary_row_values(row))


def _default_out_dir() -> str:
    """Каталог отчёта по умолчанию.

    В контейнере рабочие данные живут в томе ``/data``; писать отчёт рядом с
    ними, чтобы он переживал пересоздание контейнера. Вне Docker — локальный
    ``exports/``.
    """
    return "/data/exports" if Path("/data").is_dir() else "exports"


def _print_run_summary(summary: dict, out_dir: str) -> None:
    """Печатает отчёт и итоговую строку одного прогона."""

    path = write_audit_report(summary, out_dir=out_dir)
    print(f"Отчёт: {path}")
    print(
        f"Чанков: {summary['chunks_total']} (готово "
        f"{summary['chunks_completed']}, пропущено "
        f"{summary['chunks_skipped']}, ошибок {summary['chunks_failed']}), "
        f"расхождений с $count: {summary['count_mismatches']}"
    )
    if summary["degraded_entities"]:
        print("Data-poor (минимальный $select): "
              + ", ".join(summary["degraded_entities"]))
    if summary.get("gaps_count") is not None:
        print(f"Нереестровых Document_* подсчитано: {summary['gaps_count']}")


def _run_all_bases(
    start: str,
    end: str,
    out_dir: str,
    pause: float,
    include_unmapped: bool,
    restart: bool,
) -> int:
    """Пакетный обход активных баз: ошибка одной базы не прерывает остальные."""

    bases = db.list_bases(active_only=True)
    if not bases:
        print("Активных баз нет.", file=sys.stderr)
        return 0
    total = len(bases)
    failures = 0
    for i, base in enumerate(bases, 1):
        print(f"[{i}/{total}] {base['name']}")
        try:
            summary = run_audit(
                base, start, end, pause=pause,
                include_unmapped=include_unmapped, restart=restart,
            )
            _print_run_summary(summary, out_dir)
        except Exception as e:
            print(f"  Пропущено: {e}", file=sys.stderr)
            failures += 1
    print(f"Пакетный аудит завершён: баз {total}, с ошибками {failures}.")
    return 1 if failures else 0


def _audit_one(args) -> int:
    """Аудит одной базы по аргументам CLI (внутри уже взятой блокировки)."""

    base = _resolve_base(args.base)
    if base is None:
        names = [b["name"] for b in db.list_bases()]
        print(
            f"База '{args.base}' не найдена. "
            f"Доступные: {', '.join(names) or '-'}",
            file=sys.stderr,
        )
        return 2
    summary = run_audit(
        base, args.start, args.end, pause=args.pause,
        include_unmapped=args.include_unmapped, restart=args.restart,
    )
    _print_run_summary(summary, args.out)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m core.audit",
        description="Глубокий аудит данных баз 1С:Фреш (checkpoint-резюм).",
    )
    parser.add_argument("--base",
                        help="Имя (или URL/id) базы из таблицы bases")
    parser.add_argument("--all-bases", action="store_true",
                        help="Пакетный обход всех активных баз (по одной, "
                             "продолжает при ошибке отдельной базы)")
    parser.add_argument("--start", help="Начало периода, YYYY-MM-DD")
    parser.add_argument("--end", help="Конец периода, YYYY-MM-DD")
    parser.add_argument("--list-bases", action="store_true",
                        help="Напечатать активные базы как «id<TAB>имя» и выйти "
                             "(источник списка для пакетного обхода)")
    parser.add_argument("--summary", action="store_true",
                        help="Сводка по истории аудита (без сети): по базам "
                             "или по одной с --base")
    parser.add_argument("--problems-only", action="store_true",
                        help="С --summary: только базы с проблемами")
    parser.add_argument("--json", action="store_true",
                        help="С --summary: вывести JSON вместо таблицы")
    parser.add_argument("--include-unmapped", action="store_true",
                        help="Подсчитать нереестровые Document_* из $metadata")
    parser.add_argument("--pause", type=float, default=0.2,
                        help="Пауза между запросами, сек (по умолчанию 0.2)")
    parser.add_argument("--restart", action="store_true",
                        help="Перечитать COMPLETED-чанки заново")
    parser.add_argument("--out", default=None,
                        help="Для аудита — каталог отчёта (по умолчанию "
                             "/data/exports в контейнере, иначе exports/); "
                             "для --summary — файл (JSON при --json, иначе CSV)")
    args = parser.parse_args(argv)

    if args.list_bases:
        for b in db.list_bases(active_only=True):
            print(f"{b['id']}\t{b['name']}")
        return 0

    if args.summary:
        try:
            rows = audit_summary(args.base)
        except ValueError as e:
            print(str(e), file=sys.stderr)
            return 2
        if args.problems_only:
            rows = [r for r in rows if r["has_problems"]]
        if args.base and rows:
            payload = _summary_json(rows) if args.json else _format_base_detail(rows[0])
        else:
            payload = _summary_json(rows) if args.json else _format_summary_table(rows)
        if args.out:
            _write_summary_file(args.out, rows, as_json=args.json)
            print(f"Сводка: {args.out}")
        else:
            print(payload)
        return 0

    if args.base and args.all_bases:
        parser.error("--base и --all-bases взаимоисключающи")

    if not ((args.base or args.all_bases) and args.start and args.end):
        parser.error("--start и --end обязательны вместе с --base или "
                     "--all-bases (кроме --list-bases и --summary)")

    if args.out is None:
        args.out = _default_out_dir()

    # SIGTERM (кнопка «Остановить» в UI) ведёт себя как Ctrl+C — состояние
    # сохраняется, повторный запуск продолжит с прерванного чанка.
    _install_sigterm_handler()
    try:
        with _audit_lock(config.AUDIT_LOCK_FILE):
            if args.all_bases:
                return _run_all_bases(
                    args.start, args.end, args.out, args.pause,
                    args.include_unmapped, args.restart,
                )
            return _audit_one(args)
    except AuditBusyError as e:
        print(str(e), file=sys.stderr)
        return 3
    except KeyboardInterrupt:
        # Осознанный Ctrl+C/остановка из UI, а не сбой: прогон и незавершённый
        # чанк остаются в состоянии RUNNING, поэтому повторный запуск
        # продолжит с места прерывания (COMPLETED-чанки пропускаются).
        print(
            "\nАудит приостановлен — состояние сохранено. "
            "Повторный запуск той же команды продолжит с прерванного чанка.",
            file=sys.stderr,
        )
        return 130
    except ValueError as e:
        print(f"Аудит не выполнен: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
